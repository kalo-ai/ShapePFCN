
#include <iostream>

#include "globals.h"

namespace OPTPP {
// RELEASE = OPT++

const float OPT_GLOBALS::OPT_VERSION = 2.4;
const int OPT_GLOBALS::OPT_MINOR   = 0;

}
