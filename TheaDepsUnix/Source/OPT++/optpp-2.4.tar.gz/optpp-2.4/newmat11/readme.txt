ReadMe file for newmat11 - beta version - 19 June, 2004
-------------------------------------------------------------

This is a beta version of newmat11.

Documentation is in nm11.htm.

This library is freeware and may be freely used and distributed.

To contact the author please email robert@statsresearch.co.nz


